# RC14 Provenance-Corrective Handoff (not Product promotion)

**Original RC14 Product is byte-identical to the prior candidate.** Only the
external R01 bridge has been modified to fix cross-process request/response
replay and enforce an immutable invocation-specific request identity.

**Do not dispatch R01 yet.** The indexed Project Control State has not been
replaced and the authentic external model/search/verifier end-to-end positive
path remains unproven. The previous RC14 Handoff is superseded **for bridge
execution**, but the revised Handoff is NOT a new authoritative Product Release.

### Model-visible provenance changes

- Each bridge process gets an unpredictable 128-bit run ID.
- Every request adds a fresh per-request nonce and run ID to the actual JSON
  request bytes (including `bridge_request_identity`). The response must echo
  the SHA-256 of those exact bytes in its `request_sha256` field.
- Request files are created exclusively and rechecked for mutation before use.
- Responses from a prior process can never be silently attributed as fresh
  calls, even if copied into a new response filename.
- A response is consumable only once by the exact EvidenceStore that issued it.
- A crash leaves older request/response artifacts intact as historical evidence.
  The new process creates a new request, not a synthetic provider success.
- This prevents accidental/replayed byte collisions. It **does not** provide
  cryptographic attestation of operator-declared provider identities or prove
  independent reasoning by the verifier.

### Evidence and GitHub publication

`EVIDENCE/QA_STATUS.json` records tests, and `QA/*.py`
contains the executable provenance regressions. `PUBLICATION_PREVIEW/` contains
the separate GitHub README/Pages overlay for the future release; do not publish
the private CONTROL/EVIDENCE content to the public repository. GitHub access
will be provided later by the user, and this Handoff performs no GitHub action.

# Profound Cognition V9 — GPT-6 RC14 durable-source-reentry candidate

**CANDIDATE / NOT RELEASE.** The Project's indexed Control State remains stale;
no real external independent-provider R01 has reached a verified publication.

This package includes an actual installable Product ZIP, an execution-only file bridge,
local positive/negative test evidence, a diff ledger and an honestly reconstructed Control State.
Only the Product ZIP is the code to install. The Handoff must not become semantic runtime truth.

## External execution-only operator

1. SHA-256 verify the bundled `PRODUCT/*.zip`, then fresh-extract it without editing bytes.
2. Run `python -B HARNESS/R01_REAL_MODEL_FILE_BRIDGE.py --selftest`.
3. Securely configure the following in the operator's environment (never include secrets in files,
   chat transcripts, requests, response logs, Handoff, or model-visible context):
   `PC_R01_MODEL_PROVIDER`, `PC_R01_MODEL_ID`, `PC_R01_VERIFIER_PROVIDER`,
   `PC_R01_VERIFIER_MODEL`, `PC_R01_SEARCH_SIGNING_KEY`.
   The last must be a host-generated high-entropy secret of at least 32 characters,
   **stable across an interrupted-run resume**; the model and independent verifier
   must be different actual providers. Their declared names alone do not prove independence.
4. Run the bridge with `--product-zip PRODUCT/<actual-file-name>` and
   `--expected-product-sha256 <value written in CONTROL/LOCAL_CONTROL_STATE_RC14_CANDIDATE.md>`
   and `--evidence <directory outside Product>`.
5. The operator must fulfill the actual pending search/model/verification requests
   from **real provider tools**, preserve exact bytes and identities, and not infer
   any verdict or truth from the host HMAC itself. Only the host signs actual receipt bytes.
6. If interrupted, rerun the **identical question and Product**, with the
   **same signing key and provider identities**, the same `--evidence` directory,
   and add `--resume-checkpoint`. It reuses only historical verified search bytes,
   not epistemic completion. A changed Product, question or signer must fail closed.
7. Return all original requests/responses, source material, model-visible bytes,
   consumer states, verification and publication artifacts for independent adjudication.

## No silent stage promotion

Synthetic/TEST_ONLY checkers and source providers may validate wiring, not real epistemic
independence or publication. The Product must not be promoted merely because it is portable
or its local test suite passes. Real R01 positive liveness and Product Effect remain open.
**Do not start R02, change Product/Harness, fabricate source identities, or stamp PASS.**
