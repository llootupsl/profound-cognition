# RC14 bridge-corrective stage decision

STATE_VERSION: 2026-10-08-RC14-HARNESS-PROVENANCE-CORRECTIVE
CONTROL_GATE: BLOCKED_PROJECT_FILE_STALE__NO_RELEASE_PROMOTION
PRODUCT_SHA256: 7b538ae5cef0fce538ba1ff557f3fe1e1b61cdcd63c6c6e76a3168c14ebaa3e5
OLD_RC14_BRIDGE_SHA256: e4cecba546d0602a9eeb02c56521fe468a1750afb6aa8765194cea1e115143be
NEW_BRIDGE_SHA256: 4ef997683636a49250f27c398d6f265b6f326e56d3a48331ccc91fb09578d370
EXPERIMENT_STATUS: LOCAL_POSITIVE_AND_NEGATIVE_BRIDGE_QA_PASS; REAL_EXTERNAL_R01_UNPROVEN
EXECUTION_AGENT_AUTHORITY: RAW_EXECUTION_ONLY_NO_PRODUCT_OR_HARNESS_EDITING
NEXT_ACTION: Replace stale Project control state through authorized Project UI; independently re-read; only then authorize a single external R01 for raw evidence. R02 remains prohibited.

This is a corrected Handoff candidate, not a promotion of RC14 Product. The Project-indexed 4701... control file remains unchanged. Do not claim project attachment update, outside-world model provider attestation, or a final publication.
