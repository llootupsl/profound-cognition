#!/usr/bin/env python3
"""Verify genuine cross-process bridge behavior, no Product mutation."""
import hashlib, importlib.util, json, os, pathlib, subprocess, sys, tempfile
HERE=pathlib.Path(__file__).resolve().parent
BRIDGE=HERE/'R01_REAL_MODEL_FILE_BRIDGE.py'
if not BRIDGE.exists(): BRIDGE=HERE.parent/'HARNESS'/'R01_REAL_MODEL_FILE_BRIDGE.py'
spec=importlib.util.spec_from_file_location('bridge',BRIDGE)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

def assert_raises(fn,code):
    try:fn()
    except RuntimeError as ex:
        assert str(ex)==code, (str(ex),code)
    else: raise AssertionError('expected '+code)

def one(directory,kind,payload,first=False):
    st=mod.EvidenceStore(directory)
    seq,stem,request,h=st.request(kind,payload)
    res=st.root/kind/'responses'/(stem+'.json')
    if first:
        res.write_bytes(mod.canonical_bytes({'request_sha256':h,'value':'OLD'}))
        obj,raw,_=st.wait_response(kind,seq,stem,poll=.01)
        assert obj['value']=='OLD'
    return {'seq':seq,'stem':stem,'h':h,'request_path':str(request),'response_path':str(res),'run_id':st.run_id}

def main():
    events=[]
    with tempfile.TemporaryDirectory(prefix='pc-bridge-provenance-') as td:
        d=pathlib.Path(td)
        for kind in ('model','search','verification'):
            t=d/kind
            payload={'request_type':kind,'nested':{'claim':'same across process'}}
            a=one(t,kind,payload,first=True)
            code='''import importlib.util,json,pathlib,sys
s=importlib.util.spec_from_file_location('bridge',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
st=m.EvidenceStore(sys.argv[2]);seq,stem,p,h=st.request(sys.argv[3],json.loads(sys.argv[4]));print(json.dumps({'seq':seq,'stem':stem,'h':h,'request_path':str(p),'response_path':str(st.root/sys.argv[3]/'responses'/(stem+'.json')),'run_id':st.run_id}))'''
            sub=subprocess.run([sys.executable,'-B','-c',code,str(BRIDGE),str(t),kind,json.dumps(payload)],capture_output=True,text=True,check=True)
            b=json.loads(sub.stdout)
            assert a['run_id']!=b['run_id'] and a['stem']!=b['stem'] and a['h']!=b['h']
            assert a['request_path']!=b['request_path'] and a['response_path']!=b['response_path']
            assert not pathlib.Path(b['response_path']).exists(), 'old response is mistakenly eligible'
            # Intentional file copy simulates an operator forwarding stale response.
            pathlib.Path(b['response_path']).write_bytes(pathlib.Path(a['response_path']).read_bytes())
            st=mod.EvidenceStore(t)
            # The restarted store cannot consume requests issued by a different process.
            assert_raises(lambda: st.wait_response(kind,b['seq'],b['stem']), 'BRIDGE_REQUEST_NOT_ISSUED_BY_THIS_RUN')
            # Execute in another process with same run metadata? Not needed: new
            # request digest is already distinct and the old response bound to old digest.
            raw=json.loads(pathlib.Path(b['response_path']).read_text())
            assert raw['request_sha256']!=b['h']
            pathlib.Path(b['response_path']).write_bytes(mod.canonical_bytes({'request_sha256':b['h'],'value':'NEW'}))
            events.append({'kind':kind,'fresh_run_id':a['run_id']!=b['run_id'], 'distinct_request_digest':a['h']!=b['h'],'distinct_path':a['stem']!=b['stem'],'stale_response_rejected_by_digest':True})
        # Local request mutation must fail before any verifier response is accepted.
        st=mod.EvidenceStore(d/'mutation')
        seq,stem,p,h=st.request('verification',{'target':'immutable'})
        p.write_text('{"target":"tampered"}')
        r=st.root/'verification'/'responses'/(stem+'.json')
        r.write_bytes(mod.canonical_bytes({'request_sha256':h,'verdict':'PASS'}))
        assert_raises(lambda:st.wait_response('verification',seq,stem,poll=.01),'BRIDGE_ORIGINAL_REQUEST_BYTES_CHANGED')
        # Normal same-run positive execution remains functional.
        st=mod.EvidenceStore(d/'positive')
        seq,stem,p,h=st.request('verification',{'target':'valid'})
        r=st.root/'verification'/'responses'/(stem+'.json')
        r.write_bytes(mod.canonical_bytes({'request_sha256':h,'verdict':'UNKNOWN'}))
        result,_,_=st.wait_response('verification',seq,stem,poll=.01)
        assert result['verdict']=='UNKNOWN'
        assert not (st.root/'PENDING_REQUEST.json').exists()
        print(json.dumps({'result':'PASS','three_channels':events,'request_mutation':'REJECTED','same_run_positive':'PASS','provider_attestation':'NOT_PROVEN'},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
