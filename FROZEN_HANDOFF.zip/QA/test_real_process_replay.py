#!/usr/bin/env python3
"""Prove stale verifier output is actually rejected by a fresh process's consumer."""
import importlib.util, json, pathlib, subprocess, sys, tempfile
root=pathlib.Path(__file__).resolve().parent
BRIDGE=root/'R01_REAL_MODEL_FILE_BRIDGE.py'
if not BRIDGE.exists(): BRIDGE=root.parent/'HARNESS'/'R01_REAL_MODEL_FILE_BRIDGE.py'
sp=importlib.util.spec_from_file_location('pcbridge',BRIDGE)
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
with tempfile.TemporaryDirectory(prefix='pc_real_replay_') as d:
    s=m.EvidenceStore(d)
    seq,stem,p,h=s.request('verification',{'claim_payload':{'claim_id':'SAME'}})
    prior=pathlib.Path(d)/'verification'/'responses'/(stem+'.json')
    prior.write_bytes(m.canonical_bytes({'request_sha256':h,'pass':True,'provider_request_id':'previous-run'}))
    s.wait_response('verification',seq,stem)
    child='''import importlib.util,json,pathlib,sys
spec=importlib.util.spec_from_file_location("bridge",sys.argv[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
s=m.EvidenceStore(sys.argv[2]);seq,stem,p,h=s.request("verification",{"claim_payload":{"claim_id":"SAME"}})
resp=s.root/"verification"/"responses"/(stem+".json")
resp.write_bytes(pathlib.Path(sys.argv[3]).read_bytes())
try:s.wait_response("verification",seq,stem,poll=.01)
except RuntimeError as e:
 if str(e)!="BRIDGE_RESPONSE_REQUEST_HASH_MISMATCH": raise
else:raise AssertionError("OLD_RESPONSE_ACCEPTED")
resp.write_bytes(m.canonical_bytes({"request_sha256":h,"pass":False,"provider_request_id":"new-synthetic-response"}))
o,_,_=s.wait_response("verification",seq,stem,poll=.01)
assert o["provider_request_id"]=="new-synthetic-response"
print(json.dumps({"stale_response":"REJECTED","new_response":"ACCEPTED","different_request_hash":h!=sys.argv[4],"different_run":s.run_id!=sys.argv[5]}))'''
    r=subprocess.run([sys.executable,'-B','-c',child,str(BRIDGE),d,str(prior),h,s.run_id],capture_output=True,text=True,timeout=30)
    assert r.returncode==0,(r.returncode,r.stderr)
    v=json.loads(r.stdout)
    assert v['different_request_hash'] and v['different_run']
    print(json.dumps({'status':'PASS','cross_process_verification_consumer':v,'testing':'CONTROLLED_QA_NOT_EXTERNAL_PROVIDER_ATTESTATION'},indent=2))
